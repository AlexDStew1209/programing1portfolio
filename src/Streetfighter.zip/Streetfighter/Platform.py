class Platform
